package com.cor;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping(value = "/test")
public class Test {
	
	@RequestMapping(
            value = "/testlist",
            method = RequestMethod.GET
            )
    String home() {
        return "Hello World!";
    }

}
