package com.serverless;

import com.amazonaws.services.lambda.runtime.LambdaLogger;
import org.junit.Assert;
import org.junit.Test;

import java.util.Random;
import java.util.UUID;

import static org.junit.Assert.*;

public class HandlerTest {
	 @Test
	    public void createOktaUser() throws Exception {
/*
	        String uuid =  UUID.randomUUID().toString();
	        Handler handler = new Handler();
	        String result = handler.createOktaUser("Bill", "Jones", uuid+"@email.com", new LambdaLogger() {
	            @Override
	            public void log(String string) {

	            }
	        });
	        String ok = "<200 OK,";
	        assertTrue(result.regionMatches(0, ok,0,8));*/
	    }

	}