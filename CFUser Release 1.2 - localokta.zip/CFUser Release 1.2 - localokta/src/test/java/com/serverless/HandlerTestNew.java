package com.serverless;

import java.io.IOException;
import java.util.HashMap;

import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
public class HandlerTestNew {

    private static Object input;
    
    private static HashMap<String, String> headers = new HashMap<String, String>();
    private static HashMap<String, Object> hashMap  = null;

    @BeforeClass
    public static void createInput() throws IOException {
    	
    	headers.put("request-type","passwordpolicydetails");
    
		// TODO set up your sample input object here.
        hashMap = new HashMap<String, Object>() {{
            put("body", null);
            put("path", "/root/test");
            put("httpMethod", "GET");
            put("headers", headers);
            put("queryStringParameters", new HashMap<String, String>());
        }};


    }

    private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("LambdaForm");

        return ctx;
    }

    @Test
    public void testLambdaFormFunctionHandler() {
        Handler handler = new Handler();
        Context ctx = createContext();

        Object output = handler.handleRequest(hashMap, ctx);

        // TODO: validate output here if needed.
        if (output != null) {
            System.out.println(output.toString());
        }
    }

    }