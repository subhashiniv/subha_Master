package com.serverless;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

@RestController
public class GreetingController {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="name", defaultValue="World") String name) {
       /* return new Greeting(counter.incrementAndGet(),
                            String.format(template, name));*/
    	
    	String passCode = "123456";
    	String userid = "00ud3l75ctCI2P6j10h7";
    	String factorid= "mbld3lhtg2DgDkmu20h7";
    	RestTemplate restTemplate = new RestTemplate();
        ///String oktaUrl = "https://cargillcustomer-qa.oktapreview.com/api/v1/users/"+userid+"/factors/"+factorid+"/lifecycle/activate"; 
    	String oktaUrl = "https://dev-845440.oktapreview.com/api/v1/users/subhashini.vt@gmail.com";
        String input ="{ \"passCode\": \""+passCode+"\" }"; 
        System.out.println("activateSMSFactor oktaUrl"+oktaUrl);
        System.out.println("activateSMSFactor input: " + input);        
        HttpHeaders headers = buildHeaders();
        HttpEntity<String> entity = new HttpEntity<String>(input, headers);
        ResponseEntity<String> response = null;
        try {
        	restTemplate.setErrorHandler(new CustomResponseErrorHandler());
             response = restTemplate.exchange(oktaUrl, HttpMethod.GET, entity, String.class);          
           if (response != null) {            	
            	System.out.println("status code val::"+response);
            	//result = response.getBody();
            	//System.out.println("status code val:****:"+result);
            	//System.out.println("status code val::"+response.getStatusCodeValue());
            	//System.out.println("status code::"+response.getStatusCode());
            }
        }
       /* catch(CustomException ex) {
        	Map<String , Object> map = ex.getProperties();
        	System.out.println("HDR"+map.get("header"));
        	System.out.println("code::"+map.get("code"));
        }*/
        catch (Exception e) {   
        	e.printStackTrace();
        }
         return new Greeting(1, "subha");
    }
    
    
	public class CustomResponseErrorHandler implements ResponseErrorHandler {

		@Override
		public void handleError(ClientHttpResponse clienthttpresponse) throws IOException {
			System.out.println("handleerror*************");
			if (clienthttpresponse.getStatusCode() == HttpStatus.FORBIDDEN) {
				System.out.println("forbidden*******");
			}
		}

		@Override
		public boolean hasError(ClientHttpResponse clienthttpresponse) throws IOException {
			System.out.println("haserror**********");

			if (clienthttpresponse.getStatusCode() != HttpStatus.OK) {
				if (clienthttpresponse.getStatusCode() == HttpStatus.FORBIDDEN) {
					System.out.println("FORBIDDEN*********");
					return true;
				}
				System.out.println("haserror  not ok" + clienthttpresponse.getBody());
			}
			return false;
		}

	}
  

    
    private HttpHeaders buildHeaders(){
        HttpHeaders headers = new HttpHeaders();
      //OKTA DEVs
        headers.add("Content-Type", "application/json");
        headers.add("Accept", "application/json");
         
        //headers.add("Authorization", "SSWS 00CF4t8ih3kaVZN6kPcz5xTbr07LFdSIpcTd0XCcNC");
        headers.add("Authorization", "SSWS 00iRToPVriVFzEr0NcH6ks-ZYzoKCYB6oYZQjitprl");
       // headers.add("token", "00REwcGFhRIVwgChDd2Xc1erNDoIWbh0pFoTkxVK_s");

//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//        headers.add("Authorization", "SSWS 00-UOboUf7HlIKspzzkwqgWi1jyjs3wTG2Jjast7d2");
        return headers;
    }
}
