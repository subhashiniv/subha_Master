package com.serverless;

public class CFUserConstants {
	/*public static String CONNECTION_STRING = "jdbc:mysql://customerfacingoffshore.cscgagtbopvz.us-west-2.rds.amazonaws.com:3306/CustomerFacing";
	public static String OKTA_DOMAIN_NAME = "https://cargillcustomer-qa.oktapreview.com"; // "https://dev-845440.oktapreview.com";
	public static String ERROR_CODE = "500";
	public static String ERROR_MESSAGE = "Internal Server Error, Please try again later";	
	public static String BPAPPGRPId = "00gc4dxefvFmSveCS0h7";
	public static String BPUSERGRPID = "00gc4dxeg6jjPsRvZ0h7"; // QA
	public static String BPAPPGRPId = "00gd78esqo4HmTUF70h7";
	public static String BPUSERGRPID ="00gd78esqo4HmTUF70h7"; // DEV
	public static String OKTA_API_TOKEN ="SSWS 00CF4t8ih3kaVZN6kPcz5xTbr07LFdSIpcTd0XCcNC"; //QA
	//public static String OKTA_API_TOKEN ="SSWS 00iRToPVriVFzEr0NcH6ks-ZYzoKCYB6oYZQjitprl"; //DEV
    // public static String OKTA_API_TOKEN ="SSWS 00-UOboUf7HlIKspzzkwqgWi1jyjs3wTG2Jjast7d2"; // PROD ?
	public static String OKTA_TOKEN = "00REwcGFhRIVwgChDd2Xc1erNDoIWbh0pFoTkxVK_s";
	public static String CONTENT_TYPE ="Content-Type";
	public static String ACCEPT = "Accept";	
	public static String AUTHORIZATION = "Authorization";
	public static String APPLICATION_JSON ="application/json";*/	
	
	public static final String CONNECTION_STRING =  ReadProperties.readConfig("db.url"); 
	public static final String OKTA_DOMAIN_NAME = ReadProperties.readConfig("okta.domainname"); 
	public static final String BPAPPGRPId =ReadProperties.readConfig("bp.group.id"); 
	public static final String BPUSERGRPID = ReadProperties.readConfig("bp.user.id");
	public static final String OKTA_API_TOKEN =ReadProperties.readConfig("okta.api.token"); 
	public static final String OKTA_TOKEN = ReadProperties.readConfig("okta.token");
	
	public static final String CONTENT_TYPE ="Content-Type";
	public static final String ACCEPT = "Accept";	
	public static final String AUTHORIZATION = "Authorization";
	public static final String APPLICATION_JSON ="application/json";	
	public static final String ERROR_CODE = "500";
	public static final String ERROR_MESSAGE = "Internal Server Error, Please try again later";	
	
	
    
}
