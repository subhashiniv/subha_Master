package com.serverless;


import java.util.ResourceBundle;

public class ReadProperties {
	static String  fileName="";
	private ReadProperties () {}
	
	public  static String readConfig(String strKey)
	{
		fileName=System.getenv("propertyfile");
		if(null== fileName || fileName.equals("")) fileName="lambda";
		return ResourceBundle.getBundle(fileName).getString(strKey);
		
	}
}