package com.serverless;

public class RequestInfo {

    private String jde_api;
    private String http_method;
    
	public String getJde_api() {
		return jde_api;
	}

	public void setJde_api(String jde_api) {
		this.jde_api = jde_api;
	}

	public String getHttp_method() {
		return http_method;
	}

	public void setHttp_method(String http_method) {
		this.http_method = http_method;
	}

}
