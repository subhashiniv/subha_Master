# CustomerFacingUser
Lambda function to handle getting and updating User Data from the CustomerFacing RDS database
