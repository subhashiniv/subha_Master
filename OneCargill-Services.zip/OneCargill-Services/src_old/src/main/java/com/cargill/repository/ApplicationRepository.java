package com.cargill.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//@Repository
public class ApplicationRepository{

	private Logger logger = LoggerFactory.getLogger(ApplicationRepository.class);

		
}
