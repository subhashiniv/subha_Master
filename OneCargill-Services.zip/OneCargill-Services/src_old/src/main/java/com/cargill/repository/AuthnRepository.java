package com.cargill.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//@Repository
public class AuthnRepository{

	private Logger logger = LoggerFactory.getLogger(AuthnRepository.class);

	
	
}
