package com.cargill.repository;

//@Repository
public class FactorRepository{

	


	
}
