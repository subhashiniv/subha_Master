
package com.cargill.domain.groups;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Links {

    private List<Logo> logo = null;
    private Users users;
    private Apps apps;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public List<Logo> getLogo() {
        return logo;
    }

    public void setLogo(List<Logo> logo) {
        this.logo = logo;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Apps getApps() {
        return apps;
    }

    public void setApps(Apps apps) {
        this.apps = apps;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
