
package com.cargill.domain.groups;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupWrapper {

    private String id;
    private String created;
    private String lastUpdated;
    private String lastMembershipUpdated;
    private List<String> objectClass = null;
    private String type;
    private Profile profile;
    private Links links;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getLastMembershipUpdated() {
        return lastMembershipUpdated;
    }

    public void setLastMembershipUpdated(String lastMembershipUpdated) {
        this.lastMembershipUpdated = lastMembershipUpdated;
    }

    public List<String> getObjectClass() {
        return objectClass;
    }

    public void setObjectClass(List<String> objectClass) {
        this.objectClass = objectClass;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public Links getLinks() {
        return links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
