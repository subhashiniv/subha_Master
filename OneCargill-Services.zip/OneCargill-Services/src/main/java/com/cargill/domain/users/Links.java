
package com.cargill.domain.users;

import java.util.HashMap;
import java.util.Map;

public class Links {

    private ResetPassword resetPassword;
    private ResetFactors resetFactors;
    private ExpirePassword expirePassword;
    private ForgotPassword forgotPassword;
    private ChangeRecoveryQuestion changeRecoveryQuestion;
    private Deactivate deactivate;
    private ChangePassword changePassword;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public ResetPassword getResetPassword() {
        return resetPassword;
    }

    public void setResetPassword(ResetPassword resetPassword) {
        this.resetPassword = resetPassword;
    }

    public ResetFactors getResetFactors() {
        return resetFactors;
    }

    public void setResetFactors(ResetFactors resetFactors) {
        this.resetFactors = resetFactors;
    }

    public ExpirePassword getExpirePassword() {
        return expirePassword;
    }

    public void setExpirePassword(ExpirePassword expirePassword) {
        this.expirePassword = expirePassword;
    }

    public ForgotPassword getForgotPassword() {
        return forgotPassword;
    }

    public void setForgotPassword(ForgotPassword forgotPassword) {
        this.forgotPassword = forgotPassword;
    }

    public ChangeRecoveryQuestion getChangeRecoveryQuestion() {
        return changeRecoveryQuestion;
    }

    public void setChangeRecoveryQuestion(ChangeRecoveryQuestion changeRecoveryQuestion) {
        this.changeRecoveryQuestion = changeRecoveryQuestion;
    }

    public Deactivate getDeactivate() {
        return deactivate;
    }

    public void setDeactivate(Deactivate deactivate) {
        this.deactivate = deactivate;
    }

    public ChangePassword getChangePassword() {
        return changePassword;
    }

    public void setChangePassword(ChangePassword changePassword) {
        this.changePassword = changePassword;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
