
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Links {

    private List<Logo> logo = null;
    private List<AppLink> appLinks = null;
    private Help help;
    private Users users;
    private Deactivate deactivate;
    private Groups groups;
    private Metadata metadata;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public List<Logo> getLogo() {
        return logo;
    }

    public void setLogo(List<Logo> logo) {
        this.logo = logo;
    }

    public List<AppLink> getAppLinks() {
        return appLinks;
    }

    public void setAppLinks(List<AppLink> appLinks) {
        this.appLinks = appLinks;
    }

    public Help getHelp() {
        return help;
    }

    public void setHelp(Help help) {
        this.help = help;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Deactivate getDeactivate() {
        return deactivate;
    }

    public void setDeactivate(Deactivate deactivate) {
        this.deactivate = deactivate;
    }

    public Groups getGroups() {
        return groups;
    }

    public void setGroups(Groups groups) {
        this.groups = groups;
    }

    public Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
