
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.Map;

public class Notifications {

    private Vpn vpn;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Vpn getVpn() {
        return vpn;
    }

    public void setVpn(Vpn vpn) {
        this.vpn = vpn;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
