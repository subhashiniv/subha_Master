
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.Map;

public class Accessibility {

    private Boolean selfService;
    private Object errorRedirectUrl;
    private Object loginRedirectUrl;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Boolean getSelfService() {
        return selfService;
    }

    public void setSelfService(Boolean selfService) {
        this.selfService = selfService;
    }

    public Object getErrorRedirectUrl() {
        return errorRedirectUrl;
    }

    public void setErrorRedirectUrl(Object errorRedirectUrl) {
        this.errorRedirectUrl = errorRedirectUrl;
    }

    public Object getLoginRedirectUrl() {
        return loginRedirectUrl;
    }

    public void setLoginRedirectUrl(Object loginRedirectUrl) {
        this.loginRedirectUrl = loginRedirectUrl;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
