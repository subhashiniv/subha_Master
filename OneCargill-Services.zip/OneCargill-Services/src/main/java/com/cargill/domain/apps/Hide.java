
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.Map;

public class Hide {

    private Boolean iOS;
    private Boolean web;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Boolean getIOS() {
        return iOS;
    }

    public void setIOS(Boolean iOS) {
        this.iOS = iOS;
    }

    public Boolean getWeb() {
        return web;
    }

    public void setWeb(Boolean web) {
        this.web = web;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
