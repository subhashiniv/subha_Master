
package com.cargill.domain.users;

import java.util.HashMap;
import java.util.Map;

public class Credentials {

    private Password password;
    private RecoveryQuestion recoveryQuestion;
    private Provider provider;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Password getPassword() {
        return password;
    }

    public void setPassword(Password password) {
        this.password = password;
    }

    public RecoveryQuestion getRecoveryQuestion() {
        return recoveryQuestion;
    }

    public void setRecoveryQuestion(RecoveryQuestion recoveryQuestion) {
        this.recoveryQuestion = recoveryQuestion;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
