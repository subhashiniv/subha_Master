
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SignOn {

    private String defaultRelayState;
    private String ssoAcsUrl;
    private String idpIssuer;
    private String audience;
    private String recipient;
    private String destination;
    private String subjectNameIdTemplate;
    private String subjectNameIdFormat;
    private Boolean responseSigned;
    private Boolean assertionSigned;
    private String signatureAlgorithm;
    private String digestAlgorithm;
    private Boolean honorForceAuthn;
    private String authnContextClassRef;
    private Object spIssuer;
    private Boolean requestCompressed;
    private List<Object> attributeStatements = null;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getDefaultRelayState() {
        return defaultRelayState;
    }

    public void setDefaultRelayState(String defaultRelayState) {
        this.defaultRelayState = defaultRelayState;
    }

    public String getSsoAcsUrl() {
        return ssoAcsUrl;
    }

    public void setSsoAcsUrl(String ssoAcsUrl) {
        this.ssoAcsUrl = ssoAcsUrl;
    }

    public String getIdpIssuer() {
        return idpIssuer;
    }

    public void setIdpIssuer(String idpIssuer) {
        this.idpIssuer = idpIssuer;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getSubjectNameIdTemplate() {
        return subjectNameIdTemplate;
    }

    public void setSubjectNameIdTemplate(String subjectNameIdTemplate) {
        this.subjectNameIdTemplate = subjectNameIdTemplate;
    }

    public String getSubjectNameIdFormat() {
        return subjectNameIdFormat;
    }

    public void setSubjectNameIdFormat(String subjectNameIdFormat) {
        this.subjectNameIdFormat = subjectNameIdFormat;
    }

    public Boolean getResponseSigned() {
        return responseSigned;
    }

    public void setResponseSigned(Boolean responseSigned) {
        this.responseSigned = responseSigned;
    }

    public Boolean getAssertionSigned() {
        return assertionSigned;
    }

    public void setAssertionSigned(Boolean assertionSigned) {
        this.assertionSigned = assertionSigned;
    }

    public String getSignatureAlgorithm() {
        return signatureAlgorithm;
    }

    public void setSignatureAlgorithm(String signatureAlgorithm) {
        this.signatureAlgorithm = signatureAlgorithm;
    }

    public String getDigestAlgorithm() {
        return digestAlgorithm;
    }

    public void setDigestAlgorithm(String digestAlgorithm) {
        this.digestAlgorithm = digestAlgorithm;
    }

    public Boolean getHonorForceAuthn() {
        return honorForceAuthn;
    }

    public void setHonorForceAuthn(Boolean honorForceAuthn) {
        this.honorForceAuthn = honorForceAuthn;
    }

    public String getAuthnContextClassRef() {
        return authnContextClassRef;
    }

    public void setAuthnContextClassRef(String authnContextClassRef) {
        this.authnContextClassRef = authnContextClassRef;
    }

    public Object getSpIssuer() {
        return spIssuer;
    }

    public void setSpIssuer(Object spIssuer) {
        this.spIssuer = spIssuer;
    }

    public Boolean getRequestCompressed() {
        return requestCompressed;
    }

    public void setRequestCompressed(Boolean requestCompressed) {
        this.requestCompressed = requestCompressed;
    }

    public List<Object> getAttributeStatements() {
        return attributeStatements;
    }

    public void setAttributeStatements(List<Object> attributeStatements) {
        this.attributeStatements = attributeStatements;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
