
package com.cargill.domain.factors;

import java.util.HashMap;
import java.util.Map;

public class Links {

    private Verify verify;
    private Self self;
    private User user;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Verify getVerify() {
        return verify;
    }

    public void setVerify(Verify verify) {
        this.verify = verify;
    }

    public Self getSelf() {
        return self;
    }

    public void setSelf(Self self) {
        this.self = self;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
