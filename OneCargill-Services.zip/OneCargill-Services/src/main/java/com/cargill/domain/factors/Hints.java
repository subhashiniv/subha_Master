
package com.cargill.domain.factors;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hints {

    private List<String> allow = null;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public List<String> getAllow() {
        return allow;
    }

    public void setAllow(List<String> allow) {
        this.allow = allow;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
