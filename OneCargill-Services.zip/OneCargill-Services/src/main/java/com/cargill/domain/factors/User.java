
package com.cargill.domain.factors;

import java.util.HashMap;
import java.util.Map;

public class User {

    private String href;
    private Hints__ hints;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public Hints__ getHints() {
        return hints;
    }

    public void setHints(Hints__ hints) {
        this.hints = hints;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
