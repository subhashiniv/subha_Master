
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.Map;

public class Settings {

    private App app;
    private Notifications notifications;
    private SignOn signOn;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public App getApp() {
        return app;
    }

    public void setApp(App app) {
        this.app = app;
    }

    public Notifications getNotifications() {
        return notifications;
    }

    public void setNotifications(Notifications notifications) {
        this.notifications = notifications;
    }

    public SignOn getSignOn() {
        return signOn;
    }

    public void setSignOn(SignOn signOn) {
        this.signOn = signOn;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
