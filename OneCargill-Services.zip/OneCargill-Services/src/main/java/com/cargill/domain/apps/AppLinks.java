
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.Map;

public class AppLinks {

    private Boolean testorgoneTestsamlapp1Link;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Boolean getTestorgoneTestsamlapp1Link() {
        return testorgoneTestsamlapp1Link;
    }

    public void setTestorgoneTestsamlapp1Link(Boolean testorgoneTestsamlapp1Link) {
        this.testorgoneTestsamlapp1Link = testorgoneTestsamlapp1Link;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
