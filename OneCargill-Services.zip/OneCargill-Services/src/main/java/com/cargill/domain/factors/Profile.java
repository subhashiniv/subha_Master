
package com.cargill.domain.factors;

import java.util.HashMap;
import java.util.Map;

public class Profile {

    private String phoneNumber;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
