
package com.cargill.domain.apps;

import java.util.HashMap;
import java.util.Map;

public class Credentials {

    private UserNameTemplate userNameTemplate;
    private Signing signing;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public UserNameTemplate getUserNameTemplate() {
        return userNameTemplate;
    }

    public void setUserNameTemplate(UserNameTemplate userNameTemplate) {
        this.userNameTemplate = userNameTemplate;
    }

    public Signing getSigning() {
        return signing;
    }

    public void setSigning(Signing signing) {
        this.signing = signing;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
