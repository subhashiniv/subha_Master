package com.cargill.service;



public interface IUserService {
	



}
