package com.cargill.service;

public interface IAuthnService {
	
	

}
