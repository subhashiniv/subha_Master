package com.cargill.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class ApplicationRepository{

	private Logger logger = LoggerFactory.getLogger(ApplicationRepository.class);

		
}
