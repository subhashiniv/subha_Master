package com.cargill.repository;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {
	
	

	
}
