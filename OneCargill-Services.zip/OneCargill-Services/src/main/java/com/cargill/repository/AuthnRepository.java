package com.cargill.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class AuthnRepository{

	private Logger logger = LoggerFactory.getLogger(AuthnRepository.class);

	
	
}
