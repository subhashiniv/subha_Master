package com.cargill.util;

public interface OneCargillConstants {
	
	public static final String APPLICATION_JSON = "application/json";

}
