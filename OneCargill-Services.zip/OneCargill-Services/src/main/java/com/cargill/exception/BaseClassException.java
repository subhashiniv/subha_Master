package com.cargill.exception;

public class BaseClassException extends Exception{
	
		private static final long serialVersionUID = 1L;

		private Exception exception;

		public Exception getException() {
			return exception;
		}

		public BaseClassException(String errorCode, String errorMessage, String errorOrgin, Exception exception){
			super("Error occurred in "+errorOrgin+ " with Error code: "+ errorCode +" Error detail: "+errorMessage, exception);
			this.exception = exception;
		} 

		public BaseClassException(String errorCode, String errorMessage) {
			super("Error code: "+ errorCode +" Error detail: "+errorMessage);
		}
		
		public BaseClassException(String errorMessage) {
			super("Error detail: "+errorMessage);
	}

}
