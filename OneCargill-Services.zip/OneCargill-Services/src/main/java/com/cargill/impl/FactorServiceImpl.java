package com.cargill.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.repository.FactorRepository;
import com.cargill.service.IFactorService;

@Service
public class FactorServiceImpl implements IFactorService {

	@Autowired
	FactorRepository factorRepository;
	
	
}
