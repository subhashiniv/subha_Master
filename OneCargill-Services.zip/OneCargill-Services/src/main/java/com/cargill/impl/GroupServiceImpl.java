package com.cargill.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.repository.GroupRepository;
import com.cargill.service.IGroupService;
@Service
public class GroupServiceImpl implements IGroupService {

	@Autowired
	GroupRepository groupRepository;

	
}
