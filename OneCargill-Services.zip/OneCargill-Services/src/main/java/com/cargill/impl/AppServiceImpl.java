package com.cargill.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.repository.ApplicationRepository;
import com.cargill.service.IAppService;

@Service
public class AppServiceImpl implements IAppService {

	@Autowired
	ApplicationRepository applicationRepository;
	
	
}
