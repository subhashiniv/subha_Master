package com.cargill.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.repository.AuthnRepository;
import com.cargill.service.IAuthnService;

@Service
public class AuthnServiceImpl implements IAuthnService {

	@Autowired
	AuthnRepository authnRepository;
	
	
}
